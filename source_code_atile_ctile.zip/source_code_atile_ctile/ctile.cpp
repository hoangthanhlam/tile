/***********************************************************************************************************************/
// Stream Tiling project starts on 25 october as a result of a fun collaboration between Toon Calders, Hoang Thanh Lam, Wenjie Pei
// and some researchers from CNRS in Saint Etienne France including Andriana Prado, Elisa Fromont and Baptiste Jeudy 
/***********************************************************************************************************************/


#include <stdlib.h>
#include <string>
#include <stdio.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include<list>
#include<vector>
#include<algorithm>
#include<deque>
#include <time.h>
#include <fstream>
#include <set>
#include <sstream>

using namespace std;

int if_print =2;

//// the average number of candidates when the number of transactions > windows_size
long double average_size =0;


struct candidate{
	vector <int> items;
	int area; // the current area of the candidate
	int upper; // the upper-bound on the area of the candidate
	bool update; // true if is updated once, this field is used to avoid duplicated candidates
};

// the summary is a list of entries
struct entry{
	vector <int> items; // the transaction
	list<struct candidate> candidates; //a list of the promising candidates for the top-k tiling 
};

// compare two candidate by matching two itemsets
bool cmp_candidate(const struct candidate& c1,const struct candidate& c2){
	int i=0;
	while(i<c1.items.size()&&i<c2.items.size()){
		if(c1.items[i]==c2.items[i])
			i++;
		else
			return (c1.items[i]<c2.items[i]);
	}
	return c1.items.size()>c2.items.size();
}

// compare two candidates by its area
bool cmp_candidate_by_area(const struct candidate& c1,const struct candidate& c2){
	return c1.area>c2.area;
}

// true if two candidates represent the same itemset
bool  is_equal_candidate(const struct candidate& c1,const struct candidate& c2){
	int i=0;
	while(i<c1.items.size()&&i<c2.items.size()&&c1.items[i]==c2.items[i]){
		i++;
	}
	return (i==c1.items.size()&&i==c2.items.size());
}

// intersect two vectors and return the number of elements in the intersection
int intersection(const vector<int>& v1,const vector<int>& v2,vector<int>* v3){
	vector<int>::iterator it;
	it=set_intersection(v1.begin(),v1.end(),v2.begin(),v2.end(),v3->begin());

	return (int)(it- v3->begin());
}

// transform double to string
string double2string(double s){
	ostringstream s1;
	s1<<s;
	string s2 = s1.str();
	return s2;
}

// print summary to file for test
// output the result if line >= window_size
void print_file( const list<struct entry>& summary,int k, int window_size, int line){

	list<struct entry>::const_iterator li;
	vector<struct candidate> cans,temp;
	list<struct candidate>::const_iterator lic;
	for(li=summary.begin();li!=summary.end();li++){
		for(lic=li->candidates.begin();lic!=li->candidates.end();lic++){
			temp.push_back(*lic);
		}
	}
	sort(temp.begin(),temp.end(),cmp_candidate);
	cans.push_back(temp[0]);
	int c=1;
	while(c<temp.size()){
		if(!is_equal_candidate(temp[c-1],temp[c]))
			cans.push_back(temp[c]);
		else if(temp[c].area>cans.back().area){
			cans.back().area=temp[c].area;
			cans.back().upper=temp[c].upper;
		}
		c++;
	}
	sort(cans.begin(),cans.end(),cmp_candidate_by_area);

	if (line<=window_size)
	{
		return;
	}

	ofstream outFile;
	string filename = ".\\output\\ctile_out_w_"+double2string(window_size)+"_k_"+double2string(k)+".dat";
	if(line == window_size+1){
		outFile.open(filename.c_str());
	}
	

	else if(line > window_size+1){
		outFile.open(filename.c_str(), ios::app);

	}
	
	if(!outFile.is_open()){
		cout<<"out to file was not found!"<<endl;
		return;
	}



//	outFile<<line<<endl;
	if(line > window_size+1)
		outFile<<endl;
	for(c=0;c<cans.size()&&c<k;c++){
		outFile<<cans[c].items.size()<<" ";
		for(int j=0;j<cans[c].items.size();j++)
			outFile<<cans[c].items[j]<<"  ";
		outFile<<cans[c].area<<endl;

	}

	if (c<10)
	{
		cout<<"error: less than top k tiles!  "<<c<<" "<<line<<endl;
	}
	if(c<cans.size()){	
		int area=cans[c-1].area;
		while(c<cans.size() && area==cans[c].area){
			outFile<<cans[c].items.size()<<" ";
			for(int j=0;j<cans[c].items.size();j++)
				outFile<<cans[c].items[j]<<" ";
			outFile<<cans[c].area<<endl;
			c++;
		}
	}

	outFile<<0;


	outFile.close();

}


void summary_statistics(const list<struct entry>& summary,int line, int windows_size){
	long int sum = 0;

	list<struct entry>::const_iterator li;
	for (li = summary.begin(); li!=summary.end(); li++){
		sum += li->candidates.size();
	}
	
//	cout<<"line:"<<line<<"   "<<"number of candidates:"<<sum<<"   ";
	if(windows_size == line){
		average_size = (double)sum;
	}
	else if(line > windows_size){
		double temp = double(line - windows_size);
		average_size = temp/(temp+1) * average_size + sum / (temp+1);
	}
//	cout<<"average candidate number:"<<average_size<<endl;
}


/*******************************************************************************************************/
//Tiling function reads input file and maintains a summary of the window of length window_size 
//The summary is updated and maintained s.t. from which we can answer the top-k largest tilings exactly
/*******************************************************************************************************/
void tiling( const char *filename, int window_size, int k, int T_N){
	clock_t start, finish1, finish2;
	start = clock();

	ifstream inputFile;
	string s;
	list<struct entry> summary; 
	list<struct entry>::iterator lie; 
	list<struct candidate>::iterator lic,low; 
	vector<struct candidate> lic_temp; 
	vector<struct candidate> V;
	struct candidate iCan;
	char *cstr,*pch;

	inputFile.open(filename, fstream::in);
	if(!inputFile.is_open()){
		cout<<"Input file was not found!"<<endl;
		return;
	}
	int line=0;
	clock_t s1, f1;
	s1 = clock();
	// read the input file line by line to extract the itemset from each line
	while(getline(inputFile,s)&&line<T_N)
	{
		line++;
	
		if(line % 500 == 0){
			cout<<line<<endl;
			f1 = clock();
			cout<<"ctile: process transaction time: "<<(f1-s1)/1000000.0<<endl;
//			s1 = clock();
		}

		cstr= new char[s.size()+1];
		strcpy(cstr,s.c_str());
		struct entry iEntry;
		pch = strtok (cstr," ");

		/// remove the duplicated items
		set<int> temp_set;
		while(pch!=NULL){
			temp_set.insert(atoi(pch));
			pch = strtok (NULL," ");
		}
		
		iEntry.items.assign(temp_set.begin(), temp_set.end());

		//sort items increasingly by their ids
		sort(iEntry.items.begin(),iEntry.items.end());

		//delete the expired entry and append a new entry to the end of the summary
		if(summary.size()==window_size){
			summary.pop_front();
		}
		summary.push_back(iEntry);

		/************************************************************************************************/
		//update the list of candidates in each summary entry, candidates are the closed itemsets which are
		// promising and can become the top-k tirings in the near future 
		/************************************************************************************************/

		// the update is done backward so first we start with the last entry of the summary
		lie=summary.end();
		lie--;
		// the only candidate for the last entry of the summary is the transaction itself
		iCan.area=lie->items.size();
		iCan.upper=lie->items.size()*window_size;
		iCan.items.clear();
		iCan.items.assign(lie->items.begin(),lie->items.end());
		iCan.update=false;
		lie->candidates.push_back(iCan);
		//update the list of candidates of the other entries 
		int counter=1;
		V.clear();
		V.push_back(iCan);
		while(lie!=summary.begin()){
			counter++;
			lie--;

			for(lic=lie->candidates.begin();lic!=lie->candidates.end();lic++){
				vector<int> intersect;
				intersect.resize(summary.back().items.size());

				// decrease upper of the current candidate because of the window shift
				lic->upper -= lic->items.size(); 
				// intersect the arival transaction with every itemset in the candidate list
				int intersection_size;
				intersection_size=intersection(lic->items,summary.back().items,&intersect);

				// iff intersect is not empty
				if(intersection_size!=0){
					// insert all candidates into a temporary list
					iCan.items.clear();
					iCan.items.assign(intersect.begin(),intersect.begin()+intersection_size);

					low=lower_bound(lie->candidates.begin(),lie->candidates.end(),iCan,cmp_candidate);
					if(low==lie->candidates.end() || !is_equal_candidate(*low,iCan)){
						//if intersect does not exist in the candidate list, calculate its area and its upper-bound
						iCan.area=(lic->area/lic->items.size()+1)*iCan.items.size();
						iCan.upper=iCan.area+(window_size-counter)*iCan.items.size();
						iCan.update=false;

						//insert the intersect into the list of temporary candidates
						lic_temp.push_back(iCan);
					} else {
						//if intersect exists update its area
						if(!low->update){
							low->area+=low->items.size();
							low->update=true; //only change the area once
							low->upper+=low->items.size(); //re-increase after decreasing
						}
					}
				}
			}


			//de-duplicate the set of temporary candidates, the result of de-duplication is stored in cans
			vector<struct candidate> cans;
			sort(lic_temp.begin(),lic_temp.end(),cmp_candidate);

			int c=1;
			if(lic_temp.size()>=1)
				cans.push_back(lic_temp[0]);
			while(c<lic_temp.size()){
				if(is_equal_candidate(cans.back(),lic_temp[c])){
					if(lic_temp[c].area>cans.back().area){
						cans.back().area=lic_temp[c].area;
						cans.back().upper=lic_temp[c].upper;
					}

				} else{
					cans.push_back(lic_temp[c]);
				}
				c++;
			}

			//after de-duplication 	copy back the content from cans to lic_temp					
			lic_temp.clear();
			lic_temp.assign(cans.begin(),cans.end());



			// insert the candidate into vector V if it does not exist in V
			// if the candidate is already included in V just update the area and the upper bound  
			for(lic=lie->candidates.begin();lic!=lie->candidates.end();lic++){
				vector<struct candidate>::iterator li;
				li=lower_bound(V.begin(),V.end(),*lic,cmp_candidate);
				if(li==V.end()||!is_equal_candidate(*li,*lic)){
					V.insert(li,*lic);
				} else{
					li->area=lic->area;
					li->upper=lic->upper;
				}
				lic->update=false;
			}

			// insert the temporary candidate into vector V id it is new or
			// just update its area and upper if it exists
			for( vector<struct candidate>::iterator liic=lic_temp.begin();liic!=lic_temp.end();liic++){
				vector<struct candidate>::iterator li;
				li=lower_bound(V.begin(),V.end(),*liic,cmp_candidate);
				if(li==V.end()||!is_equal_candidate(*li,*liic)){
					V.insert(li,*liic);
				} else{
					li->area=liic->area;
					li->upper=liic->upper;
				}
			}

			sort(V.begin(),V.end(),cmp_candidate_by_area);

			//pruning existing candidates 
			for(lic=lie->candidates.begin();lic!=lie->candidates.end();){
				if(V.size()>=k && lic->upper<V[k-1].area){
					lie->candidates.erase(lic++);
				} else
					++lic;
			}

			//insert promising temporary candidates into the list of candidates
			for(vector<struct candidate>::iterator liic=lic_temp.begin();liic!=lic_temp.end();liic++){
				if(V.size()<k||liic->upper>=V[k-1].area){
					low=lower_bound(lie->candidates.begin(),lie->candidates.end(),*liic,cmp_candidate);
					lie->candidates.insert(low,*liic);
				}
			}

			// Keep only the top-k area in V
			if(V.size()>k){
				int p=k;
				while(p<V.size()&&V[p].area==V[k-1].area){
					p++;					
				}		
				V.erase(V.begin()+p,V.end());
			}
			sort(V.begin(),V.end(),cmp_candidate);
			lic_temp.clear();
		}

		//compute the average candidate number
		if(if_print == 1){
			if(line >= window_size)
			{
				summary_statistics(summary, line, window_size);
				if (line ==T_N)
					cout<<"average candidate number:"<<average_size<<endl;
			}
		}
		else if(if_print == 2){
				print_file(summary, k, window_size, line);
		}
		
		delete[] cstr;

		if (line == window_size)
		{
			finish1 = clock();
			cout<<"the time for processing first window_size transactions: "<<(finish1-start)/1000.0<<"s"<<endl;
		}
		if (line == T_N)
		{
			finish2 = clock();
			cout<<"the time for processing from "<<window_size<<" to "<<T_N<<" transactions: "<<(finish2-finish1)/1000.0<<"s"<<endl;

		}
	}
	


}



/****************************
for bat file
****************************/

int main(int argc,char **argv){
	if(argc <6){
		cout<<" usage: command inputfile window_size k Tranction_Number if_print" <<endl;
		return 0;
	}
	int window_size,k, L, T_N;
	window_size=atoi(argv[2]);
	k=atoi(argv[3]);
	T_N=atoi(argv[4]);
	if_print = atoi(argv[5]);

	clock_t start, finish;
	start = clock();
	tiling(argv[1],window_size,k, T_N);
	finish = clock();
	cout<<"total run time: "<<(finish-start) / 1000.0<<"s"<<endl;

	return 0;
}
