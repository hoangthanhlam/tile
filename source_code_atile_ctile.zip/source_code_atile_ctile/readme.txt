There are two cpp files: ctile.cpp and atile.cpp, respectively corresponding to Atile algorithm and Ctile algorithm.
I use Visual Studio 2008 to edit and complie them, and use bat file to run them. 

ctile.cpp
There are 6 input parameters: 
usage: command inputfile window_size k Tranction_Number if_print
inputfile means the path of the input data file.
Transaction_number means the index of the end of transaction you want the program to run. eg, if Transaction_Number=10000, then the program only run the streaming data from first to 10000th transaction.
if_print==0 prints nothing and is used to test the efficiency of the algorithm.
if_print==1 prints the average candidate number.
if_print==2 start to print the top k tiles after the window_size_th transaction comes.
eg of usage:
..\..\ctile\Release\ctile.exe ..\data\aol\aol.data 1000 10 2000 1 

atile.cpp
There are 7 input parameters:
usage: command inputfile window_size k L Tranction_Number if_print 
eg of usage:
..\..\ctile\Release\atile.exe ..\data\aol\aol.data 1000 10 100 2000 0

If there is any question, please feel free to contact w.pei@student.tue.nl